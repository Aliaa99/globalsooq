<?php
include 'header.php';
?>

        <!-- search form and register -->
<?php
include 'search-form.php';
?>

        <!-- about us -->
            <!-- main-header -->
    <div class="main-head">
        <div class="container">
            <a href="index.php"> الرئيسية /</a>
            <span> دخول</span>
        </div>
    </div>

    <!-- content contact-us -->
    <div class="contact-us">
        <div class="container">
            <form action="">
                <!-- inputs -->
                <div class="form-content">
                    <div class="row">
                        <div class="col-md-4 col-md-offset-4  col-sm-6 col-sm-offset-3 ">
                            <input type="email" placeholder="الايميل">
                        </div>
                    </div>
                </div>
                <!-- textarea -->
                <div class="form-content">
                    <div class="row">
                        <div class="col-md-4 col-md-offset-4  col-sm-6 col-sm-offset-3">
                            <input type="password" placeholder="كلمة المرور">
                        </div>
                    </div>
                </div>
                <!-- button -->
                <div class="form-content text-center">
                    <button>دخول الآن</button>
                </div>
                <div class="form-content text-center">
                   <p> <span> ليس لدى حساب </span><a href="#">تسجيل الآن</a></p>
                </div>
            </form>
        </div>
    </div>
    <!-- footer -->
<?php
include 'footer.php';
?>
