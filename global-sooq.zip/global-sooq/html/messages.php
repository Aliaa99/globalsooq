<?php
include 'header.php';
?>

        <!-- search form and register -->
<?php
include 'search-form.php';
?>

        <!-- about us -->
            <!-- main-header -->
    <div class="main-head">
        <div class="container">
            <a href="index.php"> الرئيسية /</a>
            <span>رسائلى </span>
        </div>
    </div>

    <!-- content messages-->
    <div class="messages">
        <div class="container">
            <div class="row">
            <!-- list -->
                <div class="col-sm-3">
                    <ul>
                        <li>
                            <a href="#">حسابى</a>
                        </li>
                        <li>
                            <a href="#">تعديل الحساب</a>
                        </li>
                        <li>
                            <a href="#">رسايلى</a>
                        </li>
                        <li>
                            <a href="#">اعلاناتى </a>
                        </li>
                        <li>
                            <a href="#">مقضلتى</a>
                        </li>
                        <li>
                            <a href="#">تسجيل خروج</a>
                        </li>
                    </ul>
                </div>
                <!-- table -->
                <div class="col-md-9">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>م</th>
                                <th>اسم المرسل</th>
                                <th>الرسالة</th>
                                <th> تاريخ الرسالة</th>
                                <th>الحالة</th>
                                <th>حذف</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>هانى</td>
                                <td>ااااااااااااووووووه</td>
                                <td>1/1/2596</td>
                                <td>مقروءة</td>
                                <td> <a href=""><i class="fa fa-times" aria-hidden="true"></i> </a> </td>
                            </tr>
                            <tr>
                                <td>1</td>
                                <td>هانى</td>
                                <td>ااااااااااااووووووه</td>
                                <td>1/1/2596</td>
                                <td>مقروءة</td>
                                <td> <a href=""><i class="fa fa-times" aria-hidden="true"></i> </a> </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                        <div class="delet-all">
                            <button>حذف الجميع</button>
                        </div>
                </div>
            </div>
        </div>
    </div>
    <!-- footer -->
<?php
include 'footer.php';
?>
