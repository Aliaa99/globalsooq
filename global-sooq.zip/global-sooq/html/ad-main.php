<?php
include 'header.php';
?>

        <!-- search form and register -->
<?php
include 'search-form.php';
?>

        <!-- about us -->
            <!-- main-header -->
    <div class="main-head">
        <div class="container">
            <a href="index.php"> الرئيسية /</a>
            <span> تفاصيل اساسية </span>
        </div>
    </div>

    <!-- content contact-us -->
    <div class="contact-us">
        <div class="container">
            <form action="">
                <!-- inputs -->
                <div class="form-content">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="input-controller row-down z-select black-select">
                                <select name="" id="">
                                    <option value="1">اختيار القسم الرئيسى </option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="input-controller row-down z-select black-select">
                                <select name="" id="">
                                    <option value="1">نوع الدفع </option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="input-controller row-down z-select black-select">
                                <select name="" id="">
                                    <option value="1">مدة الاعلان</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-4 col-sm-offset-4 ">
                            <input class=" black-select input-style" type="text" placeholder="التكلفة 0,0 ريال سعودى">
                        </div>
                    </div>
                </div>
                <!-- button -->
                <div class="form-content text-center">
                    <button>أضف تفاصيل الاعلان</button>
                </div>
            </form>
        </div>
    </div>
    <!-- footer -->
<?php
include 'footer.php';
?>
