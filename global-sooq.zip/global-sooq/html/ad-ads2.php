<?php
include 'header.php';
?>

        <!-- search form and register -->
<?php
include 'search-form.php';
?>

        <!-- about us -->
            <!-- main-header -->
    <div class="main-head">
        <div class="container">
            <a href="index.php"> الرئيسية /</a>
            <span> إضافة اعلان </span>
        </div>
    </div>

    <!-- content contact-us -->
    <div class="contact-us">
        <div class="container">
            <form action="">
                <!-- inputs -->
                <div class="form-content">
                    <div class="row">
                        <div class="col-sm-4">
                            <input type="text" placeholder="   عنوان الاعلان">
                        </div>
                        <div class="col-sm-4">
                            <div class="input-controller row-down z-select ">
                                <select name="" id="">
                                    <option value="1">حالة السلعه </option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <input type="text" placeholder="اختيار القسم">
                        </div>
                        <div class="col-sm-4">
                            <div class="input-controller row-down z-select ">
                                <select name="" id="">
                                    <option value="1">اختيار القسم الفرعى </option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <input type="text" placeholder="الدولة">
                        </div>
                        <div class="col-sm-4">
                            <input type="text" placeholder="المنطقة">
                        </div>
                        <div class="col-sm-4">
                            <input type="text" placeholder="الجوال">
                        </div>
                        <div class="col-sm-4">
                            <input type="text" placeholder="السعر">
                        </div>
                        <div class="col-sm-4">
                            <input type="text" placeholder="اضف موقعك على الخريطة">
                        </div>
                        <div class="col-sm-12">
                            <div class="multable-input">
                                <label for="">يمكن أضفاة 10 صور وفيديو</label>
                                <input name="filesToUpload[]" id="filesToUpload" type="file" multiple="" class="load-img">
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <input type="text" placeholder=" اضف رابط اليوتيوب هنا">
                        </div>
                        <div class="col-sm-12">
                            <textarea name="" id="" cols="30" rows="10" placeholder="تفاصيل الاعلان"></textarea>
                        </div>
                    </div>
                </div>
                <!-- button -->
                <div class="form-content text-center">
                    <button>أضف الاعلان الان</button>
                </div>
            </form>
        </div>
    </div>
    <!-- footer -->
<?php
include 'footer.php';
?>
