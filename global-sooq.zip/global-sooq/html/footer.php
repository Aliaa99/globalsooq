<footer>
    <!-- upfooter -->


<div class="footer" data-aos="fade-zoom-in"
     data-aos-easing="ease-out-cubic"
     data-aos-duration="1000">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-6">
                <h3>روابط مهمه</h3>
                <ul>
                    <li>
                        <a href="#">الرئيسية</a>
                    </li>
                    <li>
                        <a href="#">الاشتراك</a>
                    </li>
                    <li>
                        <a href="#">من نحن</a>
                    </li>
                    <li>
                        <a href="#">العمولة</a>
                    </li>
                    <li>
                        <a href="#">بحث متقدم</a>
                    </li>
                    <li>
                        <a href="#">مهادة استخدام الموقع</a>
                    </li>
                    <li>
                        <a href="#">تواصل معنا</a>
                    </li>
                    <li>
                        <a href="#">الاقسام</a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6 col-lg-offset-1">
                <h3>المدن</h3>
                <ul>
                    <li>
                        <a href="#">مكة</a>
                    </li>
                    <li>
                        <a href="#">تبوك</a>
                    </li>
                    <li>
                        <a href="#">الدمام </a>
                    </li>
                    <li>
                        <a href="#">القطيف</a>
                    </li>
                    <li>
                        <a href="#"> الرياض</a>
                    </li>
                    <li>
                        <a href="#">كل المدن </a>
                    </li>
                    <li>
                        <a href="#">الطائف </a>
                    </li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6 col-lg-offset-1">
                <h3>تواصل معنا</h3>
                <p><a href="#"><span>aliaa@bb4it.com </span><i class="flaticon-e-mail-envelope"></i> </a></p>
                <p><a href="#"><span>02557865454545</span> <i class="flaticon-call"></i></a></p>
                <p class="last-p">
                    <a href="#"><i class="flaticon-google-plus"></i></a>
                    <a href="#"><i class="flaticon-instagram"></i></a>
                    <a href="#"><i class="flaticon-twitter"></i></a>
                    <a href="#"><i class="flaticon-facebook-logo"></i></a>
                </p>
            </div>
        </div>
    </div>
</div>
<div class="finish">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <p>جميع الحقوق محفوظة لموقع السوق الدولى @2018</p>
            </div>
            <div class="col-sm-6">
                <p class="text-left">برمجة وتصميم <a href="https://breamx.com/">بريمكس</a></p>
            </div>
        </div>

        <!-- chat -->

<div class="chat">
   <div class="chatbody">
        <!--head name-->
            <div class="cahthead">
                <a href="#"> ahmed</a>
                <span><i class="fa fa-times" aria-hidden="true"></i></span>
            </div>
        <!-- chat-->
             <div class="chatscroll">
                 <div class="him">
                    <p> كيفك
                     </p>
                   </div>
                 <div class="me">
                     اهلين
                   </div>
               </div>
            <!--send-->
                <div class="chatsend">
                    <input type="text" placeholder="اكتب رسالتك">
                    <button><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
                </div>
            </div>
            <!--chat list-->
            <div class="chatlist">
                <ul>
                    <li class="active">
                        <a href="#">ahmed <span><i class="fa fa-times" aria-hidden="true"></i></span></a>
                    </li>
                    <li>
                        <a href="#">ahmed <span><i class="fa fa-times" aria-hidden="true"></i></span></a>
                    </li>
                </ul>
            </div>
        </div>



    </div>
</div>

</footer>

<script src="js/jquery.min.js"></script>
<script src="js/popper.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/aos.js"></script>
<script type="text/javascript" src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="js/fotorama.js"></script> <!-- 16 KB -->
<script src="js/lightbox.js"></script>
<script src="js/slick.min.js"></script>
<script>
  AOS.init();
</script>
<script src="js/main.js"></script>
</body>
</html>