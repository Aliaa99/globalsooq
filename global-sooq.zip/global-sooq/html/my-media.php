<?php
include 'header.php';
?>

        <!-- search form and register -->
<?php
include 'search-form.php';
?>

        <!-- about us -->
            <!-- main-header -->
    <div class="main-head">
        <div class="container">
            <a href="index.php"> الرئيسية /</a>
            <span> اسم المستخدم</span>
        </div>
    </div>

    <!-- content contact-us -->
    <div class="profile">
        <div class="container">
            <div class="edit-profile">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="profile-details">
                            <img src="images/bank1.png" alt="">
                            <h6>اسم المستخدم</h6>
                            <span>رقم العضوية :239 </span>
                        </div>
                    </div>
                    <div class="col-sm-3 col-sm-offset-3">
                        <button class="redbutton">تواصل معى</button>
                    </div>
                </div>
            </div>
            <div class="profile-tabes">
                     <ul class="nav nav-tabs">
                        <li class="active"><a data-toggle="tab" href="#menu1"> <i class="fas fa-project-diagram"></i>اعلاناتى </a></li>
                    </ul>

                    <div class="tab-content">
                        <!-- menu1 -->
                        <div id="menu1" class="tab-pane fade in active">
                            <div class="row">
                                <!-- div 1 -->
                                <div class="col-md-3 col-sm-4">
                                    <div class="profile-item">
                                        <img src="images/pro1.png" alt="">
                                        <h4>تبوك للسيارات</h4>
                                        <a href="#" class="location">الدمام</a>
                                        <a href="#" class="price">500 ر.س</a>
                                    </div>
                                </div>
                                <!-- div 2 -->
                                <div class="col-md-3 col-sm-4">
                                    <div class="profile-item">
                                        <img src="images/pro1.png" alt="">
                                        <h4>تبوك للسيارات</h4>
                                        <a href="#" class="location">الدمام</a>
                                        <a href="#" class="price">500 ر.س</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
        </div>
    </div>
    <!-- footer -->
<?php
include 'footer.php';
?>
