<?php
include 'header.php';
?>

        <!-- search form and register -->
<?php
include 'search-form.php';
?>

        <!-- about us -->
            <!-- main-header -->
    <div class="main-head">
        <div class="container">
            <a href="index.php"> الرئيسية /</a>
            <span> حسابات بنكية </span>
        </div>
    </div>

    <!-- content contact-us -->
    <div class="banks">
        <div class="container">
                <!-- banks accounts -->
            <div class="row">
                <div class="col-sm-6">
                    <div class="row">
                        <div class="col-xs-3">
                            <div class="bank-img">
                                <img src="images/bank1.png" alt="">
                            </div>
                        </div>
                        <div class="col-xs-9">
                            <h4>البنك الاهلى</h4>
                            <p>اسم المستفيد <span> : حساب المؤسسة</span></p>
                            <p>رقم الحساب <span> : 0447855785477 </span></p>
                            <p>ايبان <span> : sa6a488597645153645695 </span></p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="row">
                        <div class="col-xs-3">
                            <div class="bank-img">
                                <img src="images/bank1.png" alt="">
                            </div>
                        </div>
                        <div class="col-xs-9">
                            <h4>البنك الاهلى</h4>
                            <p>اسم المستفيد <span> : حساب المؤسسة</span></p>
                            <p>رقم الحساب <span> : 0447855785477 </span></p>
                            <p>ايبان <span> : sa6a488597645153645695 </span></p>
                        </div>
                    </div>
                </div>

                <div class="col-sm-12">
                    <ul class="nav nav-tabs">
                        <li class="active"><a data-toggle="tab" href="#menu1">اعلان عادى</a></li>
                        <li><a data-toggle="tab" href="#menu2">اعلان مميز</a></li>
                        <li><a data-toggle="tab" href="#menu3">عمولة</a></li>
                    </ul>

                    <div class="tab-content">
                        <div id="menu1" class="tab-pane fade in active">
                            <!-- content bank taps -->
                            <div class="bank-tabs">
                                <form action="">
                                    <!-- inputs -->
                                    <div class="form-content">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <input type="text" placeholder="اختيار البنك">
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="number" placeholder="رقم الحساب">
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="text" placeholder="اسم صاحب الحساب">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-content">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <input type="number" placeholder="الرقم المرجعى">
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="number" placeholder="المبلغ">
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="number" placeholder="رقم الاعلان">
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="date" >
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="file" >
                                            </div>
                                        </div>
                                    </div>
                                    <!-- button -->
                                    <div class="form-content text-center">
                                        <button> ارسل البيانات</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                            <!-- menu2 -->
                        <div id="menu2" class="tab-pane fade in active">
                            <!-- content bank taps -->
                            <div class="bank-tabs">
                                <form action="">
                                    <!-- inputs -->
                                    <div class="form-content">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <input type="text" placeholder="اختيار البنك">
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="number" placeholder="رقم الحساب">
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="text" placeholder="اسم صاحب الحساب">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-content">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <input type="number" placeholder="الرقم المرجعى">
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="number" placeholder="المبلغ">
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="number" placeholder="رقم الاعلان">
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="date" >
                                            </div>
                                            <div class="col-sm-4">
                                                <input type="file" >
                                            </div>
                                        </div>
                                    </div>
                                    <!-- button -->
                                    <div class="form-content text-center">
                                        <button> ارسل البيانات</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                            <!-- menu3 -->
                        <div id="menu3" class="tab-pane fade">
                            <form action="">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" value=""> أوافق على الأحكام و الشروط أتعهد وأقسم بالله أنا المعلن أن أدفع عمولة الموقع وهي1% من قيمة السلعة في حالة بيعها عن طريق الموقع وهي أمانة في ذمتي
                                    </label>
                                </div>
                                <div class="form-content text-center">
                                    <button class="button-tab">اتعهد انتقل لاضافة اعلان</button>
                                </div>
                            </form>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>
    <!-- footer -->
<?php
include 'footer.php';
?>
