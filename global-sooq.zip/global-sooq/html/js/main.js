$(document).ready(function(){
    // $('.center').slick({
    //     centerMode: true,
    //     centerPadding: '0px',
    //     slidesToShow: 2,
    //     slidesToScroll: 1,
    //     autoplay: true,
    //     vertical:true,
    //     autoplaySpeed: 2000,
    //   });
      
    $('.slider-for').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        fade: true,
        asNavFor: '.slider-nav',
        rtl: true
      });

      $('.slider-nav').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        asNavFor: '.slider-for',
        dots: true,
        centerMode: true,
        focusOnSelect: true,
        rtl: true
      });
        //   $('.pgwSlider').pgwSlider();

    $('.main-carousle .owl-carousel').owlCarousel({
        loop:true,
        margin:10,
        nav:false,
        rtl:true,
        dots:false,
        autoplay:true,
        autoplayTimeout:5000,
        responsive:{
            767:{
                items:2
            },
            0:{
                items:1
            }
        }
    });
        
    $('.sell-cars .owl-carousel').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        rtl:true,
        dots:true,
        autoplay:true,
        autoplayTimeout:5000,
        responsive:{
            767:{
                items:1
            },
            0:{
                items:1
            }
        }
    });
        
     $(".user-icon ,.close-second-menu").click(function(){
    $(".second-menu").toggle(1000);
    });
    




$('.menu-list ,.close-link-menu').click(function(){
    $('.nav-bar').animate({
        width: "toggle"
      },1000);
  
});

AOS.init({
    offset: 100,
    duration: 500,
    easing: 'ease-in-quad',
    delay: 0,
  });
  


$(window).scroll(function() {
    var scrollVal = $(this).scrollTop();
 if ( scrollVal > 50) {
     
     $('.logo-small-screen').css({'background-color':'#eee','position':'fixed'});
 }
   else{
       
     $('.logo-small-screen').css({'background-color':'transparent','position':'relative'});
   }
 
});



$('.heart i').click(function(){
    $(this).css("color","red");
});
$('.add-star').click(function(){
    $(this).find("span.media-star").toggle();
    $(this).find("div").toggle();
});


$('.various').fancybox({
    padding : 10,
    openEffect  : 'fade'
});


$('.chatlist ul li , .navnav li').click(function(){
    $(this).addClass("active").siblings().removeClass("active");
});
$('.cahthead').click(function(){
    $('.chatscroll,.chatsend,.chatlist').toggle();
});
$('.cahthead span').click(function(){
    $('.chat').toggle();
});

$('.chatlist ul li a span i').click(function(){
    $(this).parent().parent().parent().remove();
});
$('.black-select').click(function(){
    $(this).removeClass('black-select');
})
// $(".nicescroll-box").niceScroll(".wrap",{cursorcolor:"#616161",cursorwidth:"8px",background:"rgba(97,97,97,0.5)",cursorborder:"1px solid #afafaf",autohidemode:'leave'});
$(".load-img").change(function(e) {

    for (var i = 0; i < e.originalEvent.srcElement.files.length; i++) {
        
        var file = e.originalEvent.srcElement.files[i];
        
        var img = document.createElement("img");
        var reader = new FileReader();
        reader.onloadend = function() {
             img.src = reader.result;
        }
        reader.readAsDataURL(file);
        $(".load-img").before(img);



        var i = document.createElement("i");
        $(img).after(i);

        $('.multable-input i').addClass("fas fa-times-circle");
        $('.multable-input i').click(function(){
            $(this).prev().remove();
            $(this).remove();
        })

    }

    
});



});





