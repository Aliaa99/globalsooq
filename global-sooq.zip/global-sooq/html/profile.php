<?php
include 'header.php';
?>

        <!-- search form and register -->
<?php
include 'search-form.php';
?>

        <!-- about us -->
            <!-- main-header -->
    <div class="main-head">
        <div class="container">
            <a href="index.php"> الرئيسية /</a>
            <span> حسابى</span>
        </div>
    </div>

    <!-- content contact-us -->
    <div class="profile">
        <div class="container">
            <div class="edit-profile">
                <div class="row">
                    <div class="col-lg-6 col-sm-4">
                        <div class="profile-details">
                            <img src="images/bank1.png" alt="">
                            <h6>اسم المستخدم</h6>
                            <span> رقم العضوية :45878</span>
                            <div class="rates-rates">
                                <a href="#" class="rate">
                                    <i class="fas fa-star"></i>
                                </a>
                                <a href="#" class="rate">
                                    <i class="fas fa-star"></i>
                                </a>
                                <a href="#" class="rate">
                                    <i class="fas fa-star"></i>
                                </a>
                                <a href="#" class="rate">
                                    <i class="fas fa-star"></i>
                                </a>
                                <a href="#" class="rate">
                                    <i class="fas fa-star"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-4">
                        <p>تاريخ الاشتراك <span>14/4/1999</span></p>
                        <!-- <p class="paragraph-style">باقى اضافة <span>2 اعلان </span> و<span>20 يوم</span> لتجديد الاعلان</p> -->
                    </div>
                    <div class="col-lg-3 col-sm-4">
                        <button class="redbutton">الرسائل</button>
                        <button class="banafsig-button">تعديل بياناتى</button>
                    </div>
                </div>
            </div>
            <div class="profile-tabes">
                     <ul class="nav nav-tabs">
                        <li class="active"><a data-toggle="tab" href="#menu1"> <i class="fas fa-project-diagram"></i>اعلاناتى </a></li>
                        <li><a data-toggle="tab" href="#menu2"><i class="fas fa-heart"></i>المفضلة</a></li>
                        <li><a data-toggle="tab" href="#menu3"><i class="fas fa-star"></i>سجل  الاعلانات</a></li>
                        <li><a data-toggle="tab" href="#menu4"><i class="fas fa-star"></i>سجل  الاعلانات المميزه</a></li>
                        <li><a data-toggle="tab" href="#menu5"><i class="fas fa-hand-holding-usd"></i>سجل التحويلات البنكية</a></li>
                    </ul>

                    <div class="tab-content">
                        <!-- menu1 -->
                        <div id="menu1" class="tab-pane fade in active">
                            <div class="row">
                                <!-- div 1 -->
                                <div class="col-md-3 col-sm-4">
                                    <div class="profile-item">
                                        <img src="images/pro1.png" alt="">
                                        <h4>تبوك للسيارات</h4>
                                        <a href="#" class="location">الدمام</a>
                                        <a href="#" class="price">500 ر.س</a>
                                        <a href="#"><i class="fas fa-trash-alt"></i></a>
                                        <a href="#"><i class="fas fa-edit"></i></a>
                                        <div class="add-star">
                                            <span class="media-star">ميز الاعلان</span>
                                            <div class="media-perfect">
                                                <i class="fas fa-star"></i>
                                                <span>02:12:45</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-4">
                                    <div class="profile-item">
                                        <img src="images/pro1.png" alt="">
                                        <h4>تبوك للسيارات</h4>
                                        <a href="#" class="location">الدمام</a>
                                        <a href="#" class="price">500 ر.س</a>
                                        <a href="#"><i class="fas fa-trash-alt"></i></a>
                                        <a href="#"><i class="fas fa-edit"></i></a>
                                        <div class="add-star">
                                            <span class="media-star">ميز الاعلان</span>
                                            <div class="media-perfect">
                                                <i class="fas fa-star"></i>
                                                <span>02:12:45</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                            <!-- menu2 -->
                        <div id="menu2" class="tab-pane fade">
                            <div class="row">
                                <!-- div 1 -->
                                <div class="col-md-3 col-sm-4">
                                    <div class="profile-item">
                                        <img src="images/pro1.png" alt="">
                                        <h4>تبوك للسيارات</h4>
                                        <a href="#" class="location">الدمام</a>
                                        <a href="#" class="price">500 ر.س</a>
                                        <a href="#"><i class="fas fa-trash-alt"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                            <!-- menu3 -->
                        <div id="menu3" class="tab-pane fade">
                            <!-- table -->
                              <table class="table">
                                <thead>
                                    <tr>
                                        <th>رقم الاعلان</th>
                                        <th>اسم الاعلان</th>
                                        <th>نوع الاعلان</th>
                                        <th>مدة الاعلان</th>
                                        <th>تاريخ الانتهاء</th>
                                        <th>الحالة</th>
                                        <th>التكلفة</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>528598</td>
                                        <td>سيارة للبيع</td>
                                        <td>عمولة</td>
                                        <td>15 يوم</td>
                                        <td>15/5/2001</td>
                                        <td>جيده</td>
                                        <td>258 ر.س</td>
                                    </tr>
                                    <tr>
                                        <td>528598</td>
                                        <td>سيارة للبيع</td>
                                        <td>عمولة</td>
                                        <td>15 يوم</td>
                                        <td>15/5/2001</td>
                                        <td>جيده</td>
                                        <td>258 ر.س</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!-- menu4 -->
                        <div id="menu4" class="tab-pane fade">
                            <!-- table -->
                              <table class="table">
                                <thead>
                                    <tr>
                                        <th>رقم الاعلان</th>
                                        <th>اسم الاعلان</th>
                                        <th>مدة الاعلان</th>
                                        <th>تاريخ الانتهاء</th>
                                        <th>الحالة</th>
                                        <th>التكلفة</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>528598</td>
                                        <td>سيارة للبيع</td>
                                        <td>عمولة</td>
                                        <td>15/5/2001</td>
                                        <td>جيده</td>
                                        <td>258 ر.س</td>
                                    </tr>
                                    <tr>
                                        <td>528598</td>
                                        <td>سيارة للبيع</td>
                                        <td>عمولة</td>
                                        <td>15/5/2001</td>
                                        <td>جيده</td>
                                        <td>258 ر.س</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!-- menu5 -->
                        <div id="menu5" class="tab-pane fade">
                            <!-- table -->
                              <table class="table">
                                <thead>
                                    <tr>
                                        <th>م</th>
                                        <th>اسم الاعلان</th>
                                        <th>نوع الاعلان</th>
                                        <th>رقم الاعلان</th>
                                        <th>تاريخ الانتهاء</th>
                                        <th>مبلغ</th>
                                        <th>حالة التحويل</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>سيارة للبيع</td>
                                        <td>عمولة</td>
                                        <td>6858</td>
                                        <td>15/5/2001</td>
                                        <td>258 ر.س</td>
                                        <td>جيده</td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>سيارة للبيع</td>
                                        <td>عمولة</td>
                                        <td>6858</td>
                                        <td>15/5/2001</td>
                                        <td>258 ر.س</td>
                                        <td>معبق</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>

                </div>
        </div>
    </div>
    <!-- footer -->
<?php
include 'footer.php';
?>
