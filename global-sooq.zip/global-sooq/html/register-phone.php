<?php
include 'header.php';
?>

        <!-- search form and register -->
<?php
include 'search-form.php';
?>

        <!-- about us -->
            <!-- main-header -->
    <div class="main-head">
        <div class="container">
            <a href="index.php"> الرئيسية /</a>
            <span>تأكيد رقم الجوال </span>
        </div>
    </div>

    <!-- content comission-->
    <div class="contact-us">
        <div class="container">
                <form action="">
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3">
                            <input type="text" class="text-center" placeholder="ضع الكود الذى أرسل إليك">
                        </div>
                    </div>
                        <!-- button -->
                    <div class="form-content text-center">
                        <button>تسجيل الآن</button>
                    </div>
                        <!-- confident -->
                    <div class="form-content text-center">
                        <p> <span>لم يصلنى الكود </span><a href="#">ارسال مرة اخرى </a></p>
                    </div>
                </form>
        </div>
    </div>
    <!-- footer -->
<?php
include 'footer.php';
?>
