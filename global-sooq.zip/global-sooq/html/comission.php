<?php
include 'header.php';
?>

        <!-- search form and register -->
<?php
include 'search-form.php';
?>

        <!-- about us -->
            <!-- main-header -->
    <div class="main-head">
        <div class="container">
            <a href="index.php"> الرئيسية /</a>
            <span>العمولة </span>
        </div>
    </div>

    <!-- content comission-->
    <div class="comission">
        <div class="container">
            <p> اعلان مقابل نسبه 1%  على ( العقارات - السيارات - الهواتف )</p>
                <form action="">
                    <input type="text" placeholder="0">
                    <p>العمولة هى <span>0</span> ريال</p>
                </form>
        </div>
    </div>
    <!-- footer -->
<?php
include 'footer.php';
?>
