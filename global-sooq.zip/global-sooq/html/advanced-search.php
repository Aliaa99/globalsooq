<?php
include 'header.php';
?>

        <!-- search form and register -->
<?php
include 'search-form.php';
?>

        <!-- about us -->
            <!-- main-header -->
    <div class="main-head">
        <div class="container">
            <a href="index.php"> الرئيسية /</a>
            <span> بحث متقدم </span>
        </div>
    </div>

    <!-- content contact-us -->
    <div class="contact-us">
        <div class="container">
            <form action="">
                <!-- inputs -->
                <div class="form-content">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="input-controller row-down z-select">
                                <select name="" id="">
                                    <option value="1">القسم الرئيسى</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="input-controller row-down z-select">
                                <select name="" id="">
                                    <option value="1">القسم الفرعى</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="input-controller row-down z-select">
                                <select name="" id="">
                                    <option value="1">النوع</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- textarea -->
                <div class="form-content">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="input-controller row-down z-select">
                                <select name="" id="">
                                    <option value="1">المدينة</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <input type="text" placeholder="كلمة البحث">
                        </div>
                    </div>
                </div>
                <!-- button -->
                <div class="form-content text-center">
                    <button>بحث الآن</button>
                </div>
            </form>
        </div>
    </div>
    <!-- footer -->
<?php
include 'footer.php';
?>
