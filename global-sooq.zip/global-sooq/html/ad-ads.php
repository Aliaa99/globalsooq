<?php
include 'header.php';
?>

        <!-- search form and register -->
<?php
include 'search-form.php';
?>

        <!-- about us -->
            <!-- main-header -->
    <div class="main-head">
        <div class="container">
            <a href="index.php"> الرئيسية /</a>
            <span> إضافة اعلان </span>
        </div>
    </div>

    <!-- content contact-us -->
    <div class="contact-us" data-aos="zoom-in"
     data-aos-easing="ease-out-cubic"
     data-aos-duration="1000">
        <div class="container">
            <form action="">
                <!-- inputs -->
                <div class="form-content">
                    <div class="row">
                        <div class="col-sm-4">
                            <input type="text" placeholder="الاسم">
                        </div>
                        <div class="col-sm-4">
                            <input type="email" placeholder="الايميل">
                        </div>
                        <div class="col-sm-4">
                            <input type="number" placeholder="الجوال">
                        </div>
                    </div>
                </div>
                <!-- textarea -->
                <div class="form-content">
                    <textarea name="" id=""  rows="10" placeholder="الرسالة"> </textarea>
                </div>
                <!-- button -->
                <div class="form-content text-center">
                    <button>إرسال الآن</button>
                </div>
            </form>
        </div>
    </div>
    <!-- footer -->
<?php
include 'footer.php';
?>
