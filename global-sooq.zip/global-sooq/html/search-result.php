<?php
include 'header.php';
?>

        <!-- search form and register -->
<?php
include 'search-form.php';
?>

        <!-- about us -->
            <!-- main-header -->
    <div class="main-head">
        <div class="container">
            <a href="index.php"> الرئيسية /</a>
            <span>نتائج البحث</span>
        </div>
    </div>

    <!-- content sections-->
    <div class="product">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-4  col-xs-6 ">
                <div class="item">
                    <img src="images/pro1.png" alt="">
                    <button class="heart">
                        <i class="flaticon-favorite-heart-button"></i>
                    </button> 
                    <h4><a href="#">تبوك للسيارات</a></h4>
                    <p>
                        <a href="#"><i class="flaticon-facebook-placeholder-for-locate-places-on-maps"></i> الدمام </a>
                        <a href="#"><i class="flaticon-payment-method"></i> 500 ر.س </a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- footer -->
<?php
include 'footer.php';
?>
