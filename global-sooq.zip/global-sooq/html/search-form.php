 <!-- search form and register -->
<div class="search-form">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 col-md-12">
                <form action="">
                    <div class="input-controller">
                        <input type="text" placeholder="كلمة البحث">
                    </div>
                    <div class="input-controller row-down">
                        <select name="" id="">
                            <option value="1">الموقع</option>
                            <option value="1">الموقع</option>
                            <option value="1">الموقع</option>
                        </select>
                    </div>
                    <div class="input-controller row-down">
                        <select name="" id="">
                            <option value="1">الأقسام</option>
                            <option value="1">الأقسام</option>
                            <option value="1">الأقسام</option>
                        </select>
                    </div>
                    <div class="input-controller">
                        <button><i class="flaticon-magnifier"></i></button>
                        <a href="advanced-search.php" class="advanced-search adv">بحث متقدم</a>
                    </div>                   
                </form>
            </div>
            <div class="col-lg-2 col-md-3">
                <div class="register">
                    <!-- register -->
                    <!--<a href="register.php">-->
                    <!--    <i class="flaticon-man-user"></i>التسجيل-->
                    <!--</a>-->
                    <!-- login -->
                    <!--<a href="login.php">-->
                    <!--    <i class="flaticon-lock"></i>الدخول-->
                    <!--</a>-->
                    <!-- my-acount -->
                    <a href="#" class="my-acount dropdown-toggle" type="button" data-toggle="dropdown">
                        <i class="flaticon-man-user"></i>حسابى
                        <span class="caret"></span>
                    </a>
                        <ul class="dropdown-menu">
                          <li><a href="#">بروفايلى</a></li>
                          <li><a href="#">رغباتى</a></li>
                          <li><a href="#">مفضلتى</a></li>
                        </ul>
                </div>
            </div>
        </div>
    </div>
</div>
