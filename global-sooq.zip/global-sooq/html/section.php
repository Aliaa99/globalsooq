<?php
include 'header.php';
?>

        <!-- search form and register -->
<?php
include 'search-form.php';
?>

        <!-- about us -->
            <!-- main-header -->
    <div class="main-head">
        <div class="container">
            <a href="index.php"> الرئيسية /</a>
            <span>الأقسام</span>
        </div>
    </div>

    <!-- content sections-->
    <div class="section">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-4  col-xs-6 ">
                <div class="item">
                <a href="#">
                    <img src="images/pro1.png" alt="">
                    <h4> سيارات</h4>
                </a>
                </div>
            </div>
            <div class="col-md-3 col-sm-4  col-xs-6 ">
                <div class="item">
                <a href="#">
                    <img src="images/pro1.png" alt="">
                    <h4> سيارات</h4>
                </a>
                </div>
            </div>
            <div class="col-md-3 col-sm-4  col-xs-6 ">
                <div class="item">
                <a href="#">
                    <img src="images/pro1.png" alt="">
                    <h4> سيارات</h4>
                </a>
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- footer -->
<?php
include 'footer.php';
?>
