<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>sooq</title>
    <link rel="stylesheet" href="css/fontawesome-all.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-rtl.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/slick-theme.css">
    <link rel="stylesheet" href="css/lightbox.css">
    <link  href="css/fotorama.css" rel="stylesheet"> 
    <link rel="stylesheet" href="css/stylesheet.css">
    <link rel="shortcut icon" href="images/logo.png">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
<div class="logo-small-screen">
    <a href="#"><img src="images/logo.png" alt=""></a>
    <a href="#" class="menu-list"><i class="flaticon-list-menu"></i></a>   
    <a href="#" class="user-icon"><i class="flaticon-man-user"></i></a>
    <a href="#" class="language2"><img src="images/en.png" alt=""></a>
    <a href="ad-ads.php" class="add-med"><i class="fas fa-plus-square"></i></a>
    
</div>

    <div class="main-carousle">
        <div class="container">
            <div class="owl-carousel owl-theme">
                <div class="item">
                    <img src="images/Layer 2.png" alt="">
                    <div class="caption">
                        <h4>
                            <a href="#">
                                لاب توب عرض مميز جدا 
                            </a>
                        </h4>
                        <p>
                            <a href="#"><i class="flaticon-facebook-placeholder-for-locate-places-on-maps"></i> الدمام </a>
                            <a href="#"><i class="flaticon-payment-method"></i> 500 ر.س </a>
                            <a href="#"><i class="flaticon-clock"></i> منذ 5 ساعات </a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="nav-bar">
        <div class="container">
            <div class="row">
                <div class="col-sm-2">
                    <div class="logo">
                        <a href="#"><img src="images/logo.png" alt=""></a>
                        <a href="#" class="close-link-menu"><i class="fas fa-window-close"></i></a>
                    </div>
                </div>
                <div class="col-sm-8">
                    <ul class="navnav">
                        <li  class="active">
                            <a href="index.php">الرئيسية</a>
                        </li>
                        <li class="">
                            <a href="terms.php">سياسة الموقع</a>
                        </li>
                        <li class="">
                            <a href="comission.php">العموله</a>
                        </li>
                        <li class="">
                            <a href="about-us.php">الموقع</a>
                        </li>
                        <li class="">
                            <a href="section.php">الاقسام</a>
                        </li>
                        <li class="">
                            <a href="contact-us.php">تواصل معنا</a>
                        </li>
                    </ul>
                </div>
                <div class="col-sm-2">
                    <div class="nav-options">
                        <a href="ad-ads.php" class="button">أضف إعلانك</a>
                        <a href="#" class="languages"><img src="images/en.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="second-menu">
        <ul>
            <li>
                <a href="#" class="close-second-menu"><i class="fas fa-window-close"></i></a>
            </li>
            <li>
                <a href="login.php">تسجيل دخول</a>
            </li>
        </ul>
    </div>
</header>
