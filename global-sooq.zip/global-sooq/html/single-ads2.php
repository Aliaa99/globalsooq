<?php
include 'header.php';
?>

        <!-- search form and register -->
<?php
include 'search-form.php';
?>

        <!-- about us -->
            <!-- main-header -->
    <div class="main-head">
        <div class="container">
        <a href="index.php"> الرئيسية /</a>
        <a href="index.php"> سيارات /</a>
            <span> سيارات للبيع</span>
        </div>
    </div>

    <!-- content sell-cars -->
    <div class="sell-cars">
        <div class="container">
            <div class="row">
                <div class="col-sm-9">
                    <!-- lists -->
                    <ul>
                        <li class=""><i class="flaticon-facebook-placeholder-for-locate-places-on-maps"></i>
                            المنطقة : <span>السعودية,الرياض</span></li>
                        <li class=""> <i class="flaticon-call"></i>رقم الجوال : <span>054698979666</span></li>
                        <li class=""> <i class="flaticon-man-user"></i>
                            المعلن : <span>نرزان</span> 
                            <span>
                                <a href="#"><i class="fas fa-star"></i></a>
                            </span>
                            <span>
                                <a href="#"><i class="fas fa-star"></i></a>
                            </span>
                            <span>
                                <a href="#"><i class="fas fa-star"></i></a>
                            </span>
                            <span>
                                <a href="#"><i class="fas fa-star"></i></a>
                            </span>
                            <span>
                                <a href="#"><i class="fas fa-star"></i></a>
                            </span>
                             <span><a href="#">أضف تقييم</a></span>
                        
                        </li>
                        <li class=""><i class="far fa-comments"></i>راسل المعلن  : <span> <a href="#"> من هنا </a></span></li>
                        <li class=""><i class="fas fa-sync-alt"></i>حالة السلعة : <span>جيدة</span></li>
                        <li class=""><i class="far fa-clock"></i>قبل   <span>4 ساعات</span></li>
                        <li class=""><i class="fas fa-hashtag"></i>رقم الاعلان   <span>4745 </span></li>
                        <li class=""> <i class="flaticon-payment-method"></i>  <span>548,779,000 ريال سعودى </span></li>
                    </ul>
                    <!-- carousle -->
                    <div class="slide">
                        <div class="fotorama" data-nav="thumbs" data-autoplay="true" data-arrows="true" >
                            <img src="images/car.png">
                            <img src="images/pro1.png">
                            <img src="images/pro2.png">
                        </div>
                    </div>
                    <!-- details -->
                    <div class="sell-details">
                        <span class="attention2"> <a href="#">تبليغ عن الاعلان</a> </span>
                        <h4>تأمين قطع غيار معدات شيولات كتربلر فوركاو</h4>
                        <p>السلام عليكم ورحمة الله وبركاتة 
                            تامين جميع انواع قطع الغيار المستعملة و الجديدة للشيولات فوركاوا ومتسوبيشي كتربلر .. الخ ويوجد توصيل الى جميع انحاء المملكة عن طريق شركات الشحن. لطلب القطعة رقم القطعة أو صورة للقطعة إن وجدت . والموديل على وتس أب
                            (الرجاء الطلب للجادين فقط )
                            الاتصال على الجوال 
                            شعارنا الصدق والامانه و السرعة
                            ونسعي لرضائكم دائما 
                            اخوكم ابو عبدو
                            وشكرا
                        </p>

                        <div class="attention">
                            <p>أحذر من التعامل غير المباشر</p>
                            <p>استخدم القائمة السوداء قبل اى عملية تحويل</p>
                        </div>

                        <h4>التعليقات</h4>
                        <div class="see-comment">
                            <div class="img-comment">
                                <div class="row">
                                    <div class="col-sm-1">
                                        <img src="images/car.png" alt="">
                                    </div>
                                    <div class="col-sm-9">
                                        <p>محمد على </p>
                                        <span>30 دقيقة</span>
                                    </div>
                                </div>
                            </div>
                            <p class="comment">شكرا يا صديقى</p>
                            <a href="#">التبليغ عن التعليق</a>
                        </div>

                        <div class="comment-form">
                            <textarea name="" id=""  rows="6" placeholder="اترك تعليقا"></textarea>
                            <button class="banafsig-button">أضف تعليقك</button>
                        </div>
                    </div>
                </div>
                    <!-- aside -->
                <div class="col-sm-3">
                        <!-- youtube -->
                        <div class="youtube">
                            <a class="various fancybox.iframe" href="http://www.youtube.com/embed/L9szn1QQfas?autoplay=1">
                                <img class="example-image" src="images/youtube.png">
                            </a>
                        </div>
                        <!-- map -->
                        <div class="map">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m12!1m8!1m3!1d13673.827285997098!2d31.360115650000004!3d31.041379900000003!3m2!1i1024!2i768!4f13.1!2m1!1sadd+location+in+html!5e0!3m2!1sar!2seg!4v1537868530674" width="100%" height="200" frameborder="0" style="border:0" allowfullscreen></iframe>
                        </div>
                    <aside>
                        <h4>اعلانات ذات صلة</h4>
                        <div class="profile-item">
                            <img src="images/pro1.png" alt="">
                            <h4>تبوك للسيارات</h4>
                            <a href="#" class="location">الدمام</a>
                            <a href="#" class="price">500 ر.س</a>
                        </div>
                        <div class="profile-item">
                            <img src="images/pro1.png" alt="">
                            <h4>تبوك للسيارات</h4>
                            <a href="#" class="location">الدمام</a>
                            <a href="#" class="price">500 ر.س</a>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </div>


    <!-- footer -->
<?php
include 'footer.php';
?>
