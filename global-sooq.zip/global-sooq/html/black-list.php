<?php
include 'header.php';
?>

        <!-- search form and register -->
<?php
include 'search-form.php';
?>

        <!-- about us -->
            <!-- main-header -->
    <div class="main-head">
        <div class="container">
            <a href="index.php"> الرئيسية /</a>
            <span>العمولة </span>
        </div>
    </div>

    <!-- content comission-->
    <div class="comission">
        <div class="container">
            <p class="par-width">القائمة السوداء هي قائمة بإرقام حسابات وأرقام جوالات من يقومون بإساءة إستخدام الموقع لأغراض ممنوعه مثل الغش أو الأحتيال
            أو مخالفة قوانين الموقع
            </p>
                <form action="">
                    <input type="text" placeholder="ادخل رقم الحساب او الجوال">
                    <div class="form-controll">
                        <button class="banafsig-button padding-button">فحص الان </button>
                    </div>
                </form>
        </div>
    </div>
    <!-- footer -->
<?php
include 'footer.php';
?>
