<?php
include 'header.php';
?>

        <!-- search form and register -->
<?php
include 'search-form.php';
?>

        <!-- about us -->
            <!-- main-header -->
    <div class="main-head">
        <div class="container">
            <a href="index.php"> الرئيسية /</a>
            <span> حسابى</span>
        </div>
    </div>

    <!-- content contact-us -->
    <div class="profile">
        <div class="container">
            <div class="edit-profile">
                <div class="row">
                    <div class="col-md-6 col-sm-4 col-xs-12">
                        <div class="profile-details">
                            <img src="images/bank1.png" alt="">
                            <h6>اسم المستخدم</h6>
                            <span>رقم العضوية :2396</span>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-4 col-xs-12">
                        <p>تاريخ الاشتراك <span>14/4/1999</span></p>
                        <p class="paragraph-style"><a href="#" class="red">أضف إعلانك الآن</a> </p>
                    </div>
                    <div class="col-md-3 col-sm-4">
                        <button class="redbutton">الرسائل</button>
                        <button class="banafsig-button">تعديل بياناتى</button>
                    </div>
                </div>
            </div>
            <div class="profile-tabes">
                     <ul class="nav nav-tabs">
                        <li class="active"><a data-toggle="tab" href="#menu1"><i class="fas fa-heart"></i>المفضله</a></li>
                    </ul>

                    <div class="tab-content">
                        <!-- menu1 -->
                        <div id="menu1" class="tab-pane fade in active">
                            <div class="row">
                                <!-- div 1 -->
                                <div class="col-md-3 col-sm-4">
                                    <div class="profile-item">
                                        <img src="images/pro1.png" alt="">
                                        <h4>تبوك للسيارات</h4>
                                        <a href="#" class="location">الدمام</a>
                                        <a href="#" class="price">500 ر.س</a>
                                        <a href="#"><i class="fas fa-trash-alt"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
        </div>
    </div>
    <!-- footer -->
<?php
include 'footer.php';
?>
